#include <stdio.h>
#include "divisao.c"
#include "mutiplicacao.c"
#include "soma.c"
#include "subtracao.c"
#include "menu.c"

int main(){
    menu();
    return 0;

}