#include <stdio.h>
//- Coloca o maior numero do vetor primeiro
void select_sort(){




}